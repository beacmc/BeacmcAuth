package com.beacmc.beacmcauth.database;

import com.beacmc.beacmcauth.BeacmcAuth;
import com.beacmc.beacmcauth.ProtectedPlayer;
import com.beacmc.beacmcauth.config.impl.DatabaseSettings;
import com.beacmc.beacmcauth.database.dao.ProtectedPlayerDao;
import com.beacmc.beacmcauth.database.dao.impl.ProtectedPlayerDaoImpl;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import java.sql.SQLException;
import java.util.logging.Logger;

public class Database {

    private ConnectionSource connectionSource;
    private ProtectedPlayerDao protectedPlayerDao;

    public void connect() {
        assert connectionSource == null;
        try {
            DatabaseSettings database = BeacmcAuth.getConfig().getDatabaseSettings();
            connectionSource = new JdbcConnectionSource(database.getUrl(), database.getUsername(), database.getPassword());
            protectedPlayerDao = new ProtectedPlayerDaoImpl(connectionSource);
            TableUtils.createTableIfNotExists(connectionSource, ProtectedPlayer.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (connectionSource == null) {
            Logger logger = BeacmcAuth.getInstance().getLogger();
            logger.severe("Database is not connected. Server stopping...");
            BeacmcAuth.getInstance().getProxy().stop();
        }
    }

    public ProtectedPlayerDao getProtectedPlayerDao() {
        return protectedPlayerDao;
    }

    public ConnectionSource getConnectionSource() {
        return connectionSource;
    }
}
