package com.beacmc.beacmcauth.config.impl;

import com.beacmc.beacmcauth.BeacmcAuth;
import com.beacmc.beacmcauth.config.ConfigLoader;
import com.beacmc.beacmcauth.config.ConfigValue;
import com.beacmc.beacmcauth.util.Color;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.config.Configuration;
import net.md_5.bungee.config.ConfigurationProvider;
import net.md_5.bungee.config.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;

public class DiscordConfig {

    @ConfigValue(key = "token")
    private String token;

    @ConfigValue(key = "guild-id")
    private Long guildID;

    @ConfigValue(key = "code-length")
    private Integer codeLength;

    @ConfigValue(key = "time-per-confirm")
    private Integer timePerConfirm;

    @ConfigValue(key = "max-link")
    private Integer maxLink;

    private Configuration config;

    public DiscordConfig(ConfigLoader loader) {
        File file = new File(BeacmcAuth.getInstance().getDataFolder(), "discord.yml");
        try {
            config = ConfigurationProvider.getProvider(YamlConfiguration.class).load(file);
            loader.loadConfig(file, this);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getMessage(String messagePath, Map<String, String> placeholders) {
        final Configuration messages = config.getSection("messages");
        String message = messages.getString(messagePath);
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            if (entry.getKey() != null && entry.getValue() != null) {
                message = message.replace(entry.getKey(), entry.getValue());
            }
        }
        return message;
    }

    public long getRoleIdByPermission(String perm) {
        final Configuration section = config.getSection("perms-to-role-sync");
        return section.getLong(perm);
    }

    public Integer getCodeLength() {
        return codeLength;
    }

    public Integer getMaxLink() {
        return maxLink;
    }

    public Integer getTimePerConfirm() {
        return timePerConfirm;
    }

    public Long getGuildID() {
        return guildID;
    }

    public String getToken() {
        return token;
    }
}
