package com.beacmc.beacmcauth.discord;

import com.beacmc.beacmcauth.BeacmcAuth;
import com.beacmc.beacmcauth.config.impl.BaseConfig;
import com.beacmc.beacmcauth.config.impl.DiscordConfig;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.requests.GatewayIntent;

import java.util.logging.Logger;

public class DiscordProvider {

    private JDA jda;
    private Guild guild;
    private final Logger logger;
    private final BeacmcAuth plugin;

    public DiscordProvider() {
        plugin = BeacmcAuth.getInstance();
        logger = plugin.getLogger();
        init();
    }

    public void init() {
        final DiscordConfig discordConfig = BeacmcAuth.getDiscordConfig();

        jda = JDABuilder.createDefault(discordConfig.getToken(), GatewayIntent.DIRECT_MESSAGES, GatewayIntent.GUILD_MEMBERS, GatewayIntent.GUILD_INVITES, GatewayIntent.GUILD_PRESENCES, GatewayIntent.GUILD_MESSAGES, GatewayIntent.MESSAGE_CONTENT).build();
        if (!jda.getStatus().isInit()) {
            logger.severe("Discord is not initializing.");
            return;
        }

        guild = jda.getGuildById(discordConfig.getGuildID());
        if (guild == null) {
            logger.severe("Guild not found. The bot will be turned off!");
            jda.shutdownNow();
            return;
        }


    }
}
