package com.beacmc.beacmcauth.util.runnable.impl;

import com.beacmc.beacmcauth.BeacmcAuth;
import com.beacmc.beacmcauth.ProtectedPlayer;
import com.beacmc.beacmcauth.auth.AuthManager;
import com.beacmc.beacmcauth.util.runnable.BaseRunnable;
import com.beacmc.beacmcauth.config.impl.BaseConfig;
import net.md_5.bungee.api.Title;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.Map;
import java.util.concurrent.TimeUnit;

public class RegisterRunnable extends BaseRunnable {

    private final Title title;
    private final BaseComponent[] registerMessage;
    private final AuthManager authManager;
    private Integer timer;
    private Integer maxTimeAuth;

    public RegisterRunnable(ProtectedPlayer protectedPlayer) {
        super(protectedPlayer);
        BaseConfig config = BeacmcAuth.getConfig();

        timer = 0;
        maxTimeAuth = config.getTimePerRegister();
        authManager = BeacmcAuth.getAuthManager();

        title = getProxyServer().createTitle();
        registerMessage = config.getMessage("register-chat", Map.of());

        title.title(config.getMessage("register-title", Map.of()))
                .subTitle(config.getMessage("register-subtitle", Map.of()))
                .stay(80)
                .fadeIn(0)
                .fadeOut(0);

        runTaskTimer(0, 1, TimeUnit.SECONDS);
    }

    @Override
    public void run() {
        if (getProtectedPlayer().getPlayer() == null) {
            getTask().cancel();
            return;
        }

        final ProxiedPlayer player = getProtectedPlayer().getPlayer();
        final BaseConfig config = BeacmcAuth.getConfig();

        if (!authManager.getAuthPlayers().containsKey(player.getDisplayName().toLowerCase()) || !player.isConnected()) {
            getTask().cancel();
            return;
        }

        timer += 1;

        if (timer >= maxTimeAuth) {
            player.disconnect(config.getMessage("time-is-up", Map.of()));
            authManager.getAuthPlayers().remove(player.getDisplayName().toLowerCase());
            getTask().cancel();
            return;
        }

        player.sendMessage(registerMessage);
        player.sendTitle(title);
    }
}
