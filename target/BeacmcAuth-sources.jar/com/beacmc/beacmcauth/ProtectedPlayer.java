package com.beacmc.beacmcauth;

import com.beacmc.beacmcauth.config.impl.BaseConfig;
import com.beacmc.beacmcauth.database.dao.ProtectedPlayerDao;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.scheduler.TaskScheduler;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.SQLException;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@DatabaseTable(tableName = "auth_players")
public class ProtectedPlayer {

    @DatabaseField(columnName = "lowercase_name", id = true, canBeNull = false)
    private String lowercaseName;

    @DatabaseField(columnName = "real_name", canBeNull = false)
    private String realName;

    @DatabaseField(columnName = "password")
    private String password;

    @DatabaseField(columnName = "session", defaultValue = "0")
    private long session;

    @DatabaseField(columnName = "last_join", defaultValue = "0")
    private long lastJoin;

    @DatabaseField(columnName = "banned")
    private boolean banned;

    @DatabaseField(columnName = "reg_ip")
    private String registerIp;

    @DatabaseField(columnName = "last_ip")
    private String lastIp;

    private final BeacmcAuth plugin;
    private final TaskScheduler scheduler;

    public ProtectedPlayer() {
        plugin = BeacmcAuth.getInstance();
        scheduler = plugin.getProxy().getScheduler();
    }

    public ProtectedPlayer(String lowercaseName, String realName, String password, long session, long lastJoin, boolean banned, String registerIp, String lastIp) {
        plugin = BeacmcAuth.getInstance();
        scheduler = plugin.getProxy().getScheduler();
        setLowercaseName(lowercaseName);
        setRealName(realName);
        setBanned(banned);
        setSession(session);
        setLastIp(lastIp);
        setRegisterIp(registerIp);
        setLastJoin(lastJoin);
        setPassword(password);
    }

    public ProxiedPlayer getPlayer() {
        return plugin.getProxy().getPlayer(lowercaseName);
    }

    public static CompletableFuture<ProtectedPlayer> get(String name) {
        final ProtectedPlayerDao dao = BeacmcAuth.getDatabase().getProtectedPlayerDao();

        return CompletableFuture.supplyAsync(() -> {
            try {
                return dao.queryForId(name.toLowerCase());
            } catch (SQLException ignored) {
            }
            return null;
        });
    }

    public static CompletableFuture<ProtectedPlayer> create(String lowercaseName, String realName, String password, long session, long lastJoin, boolean banned, String registerIp, String lastIp) {
        final ProtectedPlayerDao dao = BeacmcAuth.getDatabase().getProtectedPlayerDao();

        return CompletableFuture.supplyAsync(() -> {
            try {
                ProtectedPlayer player = new ProtectedPlayer(lowercaseName, realName, password, session, lastJoin, banned, registerIp, lastIp);
                dao.createOrUpdate(player);
                return player;
            } catch (SQLException ignored) {
            }
            return null;
        });
    }

    public CompletableFuture<String> performLogin() {
        final ProtectedPlayerDao dao = BeacmcAuth.getDatabase().getProtectedPlayerDao();

        return CompletableFuture.supplyAsync(() -> {
            if (getPlayer() == null) {
                return null;
            }

            try {
                String ip = getPlayer().getAddress().getHostName();
                long currentTime = System.currentTimeMillis();
                dao.createOrUpdate(setLastIp(ip).setSession(currentTime).setLastJoin(currentTime));
            } catch (SQLException ignored) {
            }
            return null;
        });
    }

    public CompletableFuture<String> register(String password) {
        final ProtectedPlayerDao dao = BeacmcAuth.getDatabase().getProtectedPlayerDao();
        final BaseConfig config = BeacmcAuth.getConfig();

        return CompletableFuture.supplyAsync(() -> {
            try {
                dao.createOrUpdate(this.setPassword(BCrypt.hashpw(password, BCrypt.gensalt(config.getBCryptRounds()))));
            } catch (Throwable e) {
                e.printStackTrace();
            }
            return null;
        });
    }

    public boolean isValidIp(String ip) {
        return lastIp.equals(ip);
    }

    public boolean isSessionActive() {
        final BaseConfig config = BeacmcAuth.getConfig();
        final long currentTimeMillis = System.currentTimeMillis();
        final long sessionTimeMillis = (config.getSessionTime() * 60) * 1000;

        return currentTimeMillis - sessionTimeMillis < this.session;
    }

    public boolean checkPassword(String pass) {
        return BCrypt.checkpw(pass, this.password);
    }

    public boolean isRegister() {
        return getPassword() != null;
    }

    public ProtectedPlayer setLastJoin(long lastJoin) {
        this.lastJoin = lastJoin;
        return this;
    }

    public long getSession() {
        return session;
    }

    public long getLastJoin() {
        return lastJoin;
    }

    public String getLowercaseName() {
        return lowercaseName;
    }

    public boolean isBanned() {
        return banned;
    }

    public String getPassword() {
        return password;
    }

    public String getLastIp() {
        return lastIp;
    }

    public String getRealName() {
        return realName;
    }

    public String getRegisterIp() {
        return registerIp;
    }

    public ProtectedPlayer setPassword(String password) {
        this.password = password;
        return this;
    }

    public ProtectedPlayer setBanned(boolean banned) {
        this.banned = banned;
        return this;
    }

    public ProtectedPlayer setLastIp(String lastIp) {
        this.lastIp = lastIp;
        return this;
    }

    public ProtectedPlayer setLowercaseName(String lowercaseName) {
        this.lowercaseName = lowercaseName.toLowerCase();
        return this;
    }

    public ProtectedPlayer setRealName(String realName) {
        this.realName = realName;
        return this;
    }

    public ProtectedPlayer setRegisterIp(String registerIp) {
        this.registerIp = registerIp;
        return this;
    }

    public ProtectedPlayer setSession(long session) {
        this.session = session;
        return this;
    }
}
