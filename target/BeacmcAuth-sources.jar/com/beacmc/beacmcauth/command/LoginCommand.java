package com.beacmc.beacmcauth.command;

import com.beacmc.beacmcauth.BeacmcAuth;
import com.beacmc.beacmcauth.ProtectedPlayer;
import com.beacmc.beacmcauth.auth.AuthManager;
import com.beacmc.beacmcauth.config.impl.BaseConfig;
import com.beacmc.beacmcauth.database.dao.ProtectedPlayerDao;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;
import org.mindrot.jbcrypt.BCrypt;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class LoginCommand extends Command {

    private final AuthManager authManager;
    private final ProtectedPlayerDao dao;

    public LoginCommand() {
        super("login", null, "log", "l");
        authManager = BeacmcAuth.getAuthManager();
        dao = BeacmcAuth.getDatabase().getProtectedPlayerDao();
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof ProxiedPlayer)) {
            sender.sendMessage(TextComponent.fromLegacyText("Only player"));
            return;
        }

        final ProxiedPlayer player = (ProxiedPlayer) sender;
        final BaseConfig config = BeacmcAuth.getConfig();

        if (!authManager.getAuthPlayers().containsKey(player.getDisplayName().toLowerCase())) {
            player.sendMessage(config.getMessage("already-authed", Map.of()));
            return;
        }

        final CompletableFuture<ProtectedPlayer> future = ProtectedPlayer.get(player.getDisplayName().toLowerCase());

        future.thenAccept(protectedPlayer -> {
            if (!protectedPlayer.isRegister()) {
                player.sendMessage(config.getMessage("not-register", Map.of()));
                return;
            }

            if (args.length < 1) {
                player.sendMessage(config.getMessage("enter-password", Map.of()));
                return;
            }

            if (!BCrypt.checkpw(args[0], protectedPlayer.getPassword())) {
                int attempts = authManager.getAuthPlayers().get(protectedPlayer.getLowercaseName());
                authManager.getAuthPlayers().put(protectedPlayer.getLowercaseName(), attempts - 1);

                player.sendMessage(config.getMessage("wrong-password", Map.of("%attempts%", String.valueOf(attempts - 1))));
                if (authManager.getAuthPlayers().get(protectedPlayer.getLowercaseName()) <= 0) {
                    player.disconnect(config.getMessage("attempts-left", Map.of()));
                }
                return;
            }

            player.sendMessage(config.getMessage("login-success", Map.of()));
            authManager.getAuthPlayers().remove(protectedPlayer.getLowercaseName());
            protectedPlayer.performLogin();
            authManager.connectPlayerToServer(player, config.findServerInfo(config.getGameServers()));
        });
    }
}
